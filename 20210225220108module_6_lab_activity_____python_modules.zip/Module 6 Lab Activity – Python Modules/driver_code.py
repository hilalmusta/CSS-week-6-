# importing the created functions
import my_module

print("\nrandomNumbers function")
# testing randomNumbers function
my_module.randomNumbers()

print("\nrandomListElement function")
# creating list and store elements
testList = list()
testList = [5,6,3,2,1,8,9]
# testing randomListElement function
print(my_module.randomListElement(testList))

print("\nrandOddInt function")
# testing randOddInt function
print(my_module.randOddInt())

print("\npythagorean function")
# testing pythagorean function
print(my_module.pythagorean(3,4))