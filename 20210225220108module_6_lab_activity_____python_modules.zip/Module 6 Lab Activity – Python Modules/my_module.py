# importing necessary libraries
from random import *
from math import *

# generate 10 random numbers between 25 to 35 and print them
def randomNumbers():
    # looping for 10 numbers
    for i in range(10):
        # printing the random integer between given range
        print(randint(25,35))

# returns a random element from a list
def randomListElement(listX):
    # get the size of list
    val = len(listX)
    # returning the random element taken from list
    return listX[randint(0,val-1)]

# return and odd number between 0 to 100
def randOddInt():
    # continuesly running
    while True:
        # generate random integer
        num = randint(0,100)
        # chec whether it is odd or not
        if num%2 == 1:
            # if odd break 
            break
        # return the value
    return num

# calculating hyptoaneous using pythagoreous theorem
def pythagorean(a,b):
    # create a new variable c and calculating it using the given equation
    c = sqrt(pow(a,2)+pow(b,2))
    # returning the answer
    return c